
<!DOCTYPE html>
<html>
<head>
	<title>Upcoming Events</title>
</head>
<body>
<br/>
<br/>
<br/>
<br/>
<br/>
            <center>

         <table border=1>
		 <tr><td colspan=5><center><b>Upcoming Events</b></center></td></tr>
		 <tr>
		 <td>Event ID</td>
		 <td>Event Date</td>
		 <td>Subject</td>
		 <td><center>Event Detail</center></td>
		 </tr>
		 
		 <tr>
		 <td>1</td>
		 <td>17/3/2020</td>
		 
		 <td>Mujib100</td>
		 <td>
          Relive the iconic moments that changed the course of history for our nation and witness the unfolding <br/>
          of momentous events as Bangabandhu Sheikh Mujibur Rahman makes his iconic and legendary speeches.</td>
		 </tr>
		 
		 <tr>
		 <td>2</td>
		 <td>26/3/2020</td>
		 
		 <td>Independence Day</td>
		 <td>
          College will remain closed in  26th March 2020 due to Independence day makeup class of the respected <br/>
		   subject will be announced later
		 
          
		 </tr>
		 
		 <tr><td colspan=5><center><a href='Home.php'>Go home</a></center></td></tr>
		 
		 
		 
		 </table>
		 
		 </center>
		 
</body>
</html>