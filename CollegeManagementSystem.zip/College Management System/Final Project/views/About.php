

<!DOCTYPE html>
<html>
<head>
	<title>About us</title>
</head>
<body>
<br/>
<br/>
<br/>
<br/>
<br/> <center>
           <h2> Information About the Institue </h2>
    <table border=1 width=500 height=200>
	     
	  <tr> <td valign="middle">  <b> Our College is committed to provide quality and excellent computer-based academic programs responsive to the emerging challenges of the time. It is dedicated to nurture and produce competent world class professional imbued with strong sense of ethical values ready to face the competitive world of arts, business, science, social science and technology.  </b>    </td>  </tr>
	  
	</table>
	<a href='home.php'>Go Home</a>
        
	</center>	 
</body>
</html>