<?php
            require_once("../service/functions.php");
			
			
			
			$request=DeleteStudent();
			
			
?>





