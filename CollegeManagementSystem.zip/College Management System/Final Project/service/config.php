<?php 
$conn = mysqli_connect(
    
    "localhost", //host
    "root", //username
    "", //password
    "college" //database name
    
    ) or die("connection file!");
    
    
$hostName = 'http://localhost/student';//site Host name
 ?>
